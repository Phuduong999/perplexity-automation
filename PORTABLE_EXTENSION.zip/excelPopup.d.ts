/**
 * Clear state from chrome.storage
 */
export declare function clearState(): Promise<void>;
//# sourceMappingURL=excelPopup.d.ts.map