import './reload';
//# sourceMappingURL=background.d.ts.map