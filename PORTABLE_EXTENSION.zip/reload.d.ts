/**
 * Auto-reload extension when files change (Development only)
 * This watches for changes in the dist folder and reloads the extension
 */
export {};
//# sourceMappingURL=reload.d.ts.map